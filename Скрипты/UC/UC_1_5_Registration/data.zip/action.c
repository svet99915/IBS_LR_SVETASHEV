Action()
{

	web_url("webtours", 
		"URL=http://127.0.0.1:1080/webtours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_link("sign up now", 
		"Text=sign up now", 
		"Snapshot=t3.inf", 
		LAST);

	lr_think_time(74);

	web_submit_form("login.pl", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo11", ENDITEM, 
		"Name=password", "Value=bean11", ENDITEM, 
		"Name=passwordConfirm", "Value=bean11", ENDITEM, 
		"Name=firstName", "Value=Coco", ENDITEM, 
		"Name=lastName", "Value=Jumbo", ENDITEM, 
		"Name=address1", "Value=Streeet", ENDITEM, 
		"Name=address2", "Value=Cityy", ENDITEM, 
		"Name=register.x", "Value=34", ENDITEM, 
		"Name=register.y", "Value=9", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_image("button_next.gif", 
		"Src=/WebTours/images/button_next.gif", 
		"Snapshot=t5.inf", 
		LAST);

	return 0;
}